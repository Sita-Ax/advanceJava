public class Person extends NPC implements Runnable{//this is a subclass

    private int position;
    private Inventory inventory;
    private int LastRoom;
    private  Game game;

    public Person(String name, int startRoom, Game game) {
        super(name);
        //persons start position
        this.position = startRoom;
        //persons inventory that takes 1 inventory
        this.inventory = new Inventory(1);
        this.game = game;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    @Override
    public void run(){
        //this is the room that person is in before it went to next
        LastRoom = this.position;
        //the random number that the person get in the threads
        int random = (int)(Math.random()*4);
        //person also get a random position
        this.position = random;

        try {
            //take from room to add and remove the person
            game.getRoom(this.LastRoom).remove(this);
            game.getRoom(this.position).addNpc(this);
        }catch (Exception e){
            e.printStackTrace();
        }
        //this just to know what prints out in the terminal
       System.out.println(this.name +this.position + this.inventory);
    }
    //this print out inside gui
    @Override
    public String toString() {
        return this.name + " is carrying " + this.inventory;
    }

    public int getPosition(){
        return this.position;
    }
    public int getLastRoom(){
        return this.LastRoom;
    }
}
