import java.util.Arrays;
import java.util.stream.Stream;

public class Inventory {
    //inventory list of GameObject one list and one size how many things can this inventory contains
    private GameObject[] list;
    private int size;
    private boolean isItFull = false;

    public Inventory(int size) {
        //this inventory should be size size
        this.size = size;
        list = new GameObject[size];
    }

    //streams, take in a object of the list and put it in our list
    public void addObject(GameObject go) {
        //this adds our inventory of GameObjects
        //list[0]=go; //this is one the first position and write over if it already there
        //count list and look for the first empty place
        int index = getFirstEmptyIndex();
       /* Stream<GameObject> streamAdd = Stream.of(list);
        streamAdd.forEach(s-> System.out.println(go));
        System.out.println(streamAdd);

        */
       for (int i = 0; i < list.length; i ++){
            if (list[i] == null){
                list[i] = go;
                return;
            }
        }


    for (int i = 0; i == list.length; i++){
            System.out.println("Your inventory is full! ");
            return;
        }
    }
        //this.list[index] = go;

    public GameObject grab(String name) {
        return moveObject(name, false);
    }

    GameObject moveObject(String name, boolean ignoreUnmovable) {
        for (int i = 0; i < list.length; i++) {
            GameObject object = list[i];
            if (object == null) continue;
            if (!object.isMovable() && !ignoreUnmovable) continue;
            if (object.getName().equalsIgnoreCase(name)) {
                list[i] = null;
                return object;
            }
        }
        return null;
    }
    //get some chest
    GameObject getCoffin(String name, boolean ignoreUnmovable) {
        for (int i = 0; i < list.length; i++) {
            GameObject object = list[i];
            if (object == null) continue;
            if (!object.isMovable() && !ignoreUnmovable) continue;
            if (object.getName().equalsIgnoreCase(name)) {
                return object;
            }
        }
        return null;
    }
    GameObject getDoor(String name, boolean ignoreUnmovable) {
        for (int i = 0; i < list.length; i++) {
            GameObject object = list[i];
            if (object == null) continue;
            if (!object.isMovable() && !ignoreUnmovable) continue;
            if (object.getName().equalsIgnoreCase(name)) {
                return object;
            }
        }
        return null;
    }

    //find a key that fit to this container
    Key findKey(Container container) {
        for (int i = 0; i < list.length; i++) {
            GameObject object = list[i];
            if (object == null) continue;
            if (object instanceof Key) {
                //this is casting for key
                Key key = (Key) object;
               //if (key.fit(container)){
                   return key;
               }
            }
        return null;
    }

    //find a key that fit to this door
    Key findDoorKey(Container door) {
        for (int i = 0; i < list.length; i++) {
            GameObject object = list[i];
            if (object == null) continue;
            if (object instanceof Key) {
                Key key = (Key) object;
                // if (key.fit(container))
                return key;
            }
        }
        return null;
    }

    //one that you work whit and one that you send in or switch//get a name from an array or take it away if its still are there
   /* public void moveObject(Inventory i2, GameObject go) {

        if (i2.equals(isItFull)){
            System.out.println("No plizz grab something ");
            if (go.isMovable())addObject(go);
        }
       if (i2.equals(go)){
            System.out.println("in move");
           addObject(go);
        }
       if (!i2.equals(isItFull)){
           System.out.println("You can´t pick up anything");
       }
        if (!i2.equals(go)){
            System.out.println("no in");
        }
        //isObjectHere(go private)  //otherwise Its not here(!isOb(GO)){fel}
        System.out.println("inventmove");
        i2.addObject(go);
        //this.removeObject(go);
    }

    */

    //print out our inventory
    public String toString() {
        return Arrays.toString(this.list);
    }

    private int getFirstEmptyIndex() {
        //this will only get from the addobject so it is private take the first empty place in our list that print null
        //stream är main null filter i stream där det finns plats
       // Arrays.stream(list).filter(Objects::isNull).toArray();
       // return Arrays.asList(list).indexOf(null);
        for (int i = 0; i < this.list.length; i++){
            if (this.list[i] == null){
                return i;
            }
        }
        return -1;
    }
}


