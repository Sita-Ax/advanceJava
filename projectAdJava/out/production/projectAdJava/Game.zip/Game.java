import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Game implements Runnable{

    private GUI gui;
    private Room room1, room2, room3, room4;
    private Room [] map;
    private Person [] npc;
    private GameObject [] objects;
    private int currentRoom;
    private Player player;
    private boolean running;

    private Inventory inventory = new Inventory(10);

    Container coffin = new Container("coffin", false, true);
    Container door = new Container("Door", false, true);
    //create 2 key one to the coffin and one to the door
    Key key1 = new Key("key#1", true, coffin);
    Key key2 = new Key("key#2", true, door);

    public Game() {

        //create a Room and the class i just a print
        room1 = new Room("First room ", " Just whit black walls");
        room2 = new Room("Second room ", " The smallest room");
        room3 = new Room("Basement room ", " It is just in stone");
        room4 = new Room("Last room ", " The biggest ");

        //a map that contains array size 4 like index
        map = new Room[4];
        map[0] = room1;
        map[1] = room2;
        map[2] = room3;
        map[3] = room4;

        //create 10 GameObject whit name and if it is movable or not
        GameObject sofa = new GameObject("sofa", false);
        GameObject screwdriver = new GameObject("screwdriver", true);
        GameObject knife = new GameObject("knife", true);
        GameObject chair = new GameObject("chair", false);
        GameObject scissor = new GameObject("scissor", true);
        GameObject table = new GameObject("table", false);
        GameObject key1 = new GameObject("key1", true);
        GameObject cup = new GameObject("cup", true);
        GameObject key2= new GameObject("key2", true);
        GameObject lamp = new GameObject("roof lamp", false);

        //containers i create above the game constructor so i can use it everywhere
        //Container box = new Container(" The coffin ", false , true);

        //what is in the room from the beginning
        room1.addObject(sofa);
        room1.addObject(screwdriver);
        room1.addObject(knife);
        room2.addObject(table);
        room2.addObject(scissor);
        room2.addObject(chair);
        room3.addObject(cup);
        room3.addObject(lamp);
        room4.addObject(key1);
        room4.addObject(key2);

        //this is instance of person
        Person TureSventon = new Person(" Ture Sventon ", 0, this);
        Person Freddy = new Person(" Freddy ", 1, this);
        Person Jason = new Person(" Jason ", 2, this);

        //this rooms the npc begins in
        room1.addNpc(TureSventon);
        room2.addNpc(Freddy);
        room3.addNpc(Jason);

        this.npc = new Person[3];
        npc[0] = TureSventon;
        npc[1] = Freddy;
        npc[2] = Jason;
        //this is the inventory of person from start
        npc[0].getInventory().addObject(screwdriver);
        npc[1].getInventory().addObject(scissor);
        npc[2].getInventory().addObject(cup);

        //walk around the room concurrent room and pick up and put down things in a thread it takes 6 treads
        ScheduledThreadPoolExecutor pool = new ScheduledThreadPoolExecutor(5);
        pool.scheduleAtFixedRate(Jason, 2, 10, TimeUnit.SECONDS);
        pool.scheduleAtFixedRate(Freddy, 5, 10, TimeUnit.SECONDS);
        pool.scheduleAtFixedRate(TureSventon, 9, 10, TimeUnit.SECONDS);

        //here start the gui
        this.gui = new GUI();

        //take in commands take a position and to string to print out. start pos
        int position = 0;
        gui.setShowRoom(map[position].toString());

        //tex if i am in room 3 cant move into room 1 if sats a new if sats
        while (true) {
            String command = gui.getCommand();//get new command
            String arg[] = command.split(" ");
            if (command != null) {
                if (command.contains("room1")) {
                    position = 0;
                    if (command.contains("room3") || command.contains("room4")) {
                        System.out.println("You can´t go here! ");
                    }
                }
                if (command.contains("room2")) {
                    position = 1;
                    if (command.contains("room4")) {
                        System.out.println("You can´t go here! ");
                    }
                }
                if (command.contains("room3")) {
                    position = 2;
                    if (command.contains("room1")) {
                        System.out.println("You can´t go here! ");
                    }
                }
                if (command.contains("room4")) {
                    position = 3;
                    if (command.contains("room2") || command.contains("room1")) {
                        System.out.println("You can´t go here! ");
                    }
                }
                if (command.contains("move")) {
                    System.out.println("in game");
                    show();
                }
                if (command.contains("grab")) {
                    //from the room that player is in
                    Room current = getCurrentRoom();
                    GameObject item = current.getInventory().grab(arg[1]);
                    inventory.addObject(item);
                }
                if (command.contains("drop")) {
                    Room current = getCurrentRoom();
                    GameObject item = inventory.grab(arg[1]);
                    current.getInventory().addObject(item);
                }
                if (command.contains("Unlock coffin")) {
                    //if it get more than one take agr[1] in
                    GameObject getcoffin = getCurrentRoom().getInventory().getCoffin(arg[1], true);
                    //if this is the coffin is a container use instanceof
                    if (getcoffin instanceof Container) {
                        //save this container to coffin casting because we know that this is the coffin
                        Container coffin = (Container) getcoffin;
                        //this is the key to coffin
                        Key findKeys = inventory.findKey(coffin);
                        if (findKeys != null) {
                            //unlock the coffin
                            coffin.locked = false;
                        }
                    } else {
                        System.out.println("You can´t open!");
                    }
                    if (command.contains("Unlock door")) {
                        //if it get more than one take agr[1] in
                        GameObject getDoor = getCurrentRoom().getInventory().getDoor(arg[1], true);
                        //if this is the coffin is a container use instanceof
                        if (getDoor instanceof Container) {
                            //save this container to coffin casting because we know that this is the coffin
                            Container door = (Container) getDoor;
                            //this is the key to coffin
                            Key findDoorKeys = inventory.findDoorKey(door);
                            if (findDoorKeys != null) {
                                //unlock the coffin
                                door.locked = false;
                            }
                        } else {
                            System.out.println("You can´t open!");
                        }
                    }
                }
                //showroom that room iam in update
                gui.setShowRoom(map[position].toString());
                //what is in the inventory
                gui.setShowInventory(inventory);
                //if the map dosen´t contains null print out otherwise don't do anything
                if (map[position].getPerson() != null) {
                    //when i change it will show how is inside the room
                    gui.setShowPersons(map[position].getPerson());
                }
            }
        }
    }

    public Room getRoom(int position) {
        return map[position];
    }

    //this is output depends were the player is
    public void setCurrentRoom(int index){
       //get a room from index
       Room room = map[index];
       Inventory inventory ;
       String description = room.getDescription();
       //show in gui
        gui.setShowRoom(description);
        currentRoom = index;
    }

    public void show(){
        System.out.println(this.currentRoom +" is in game "+ this.npc + this.objects);
    }
/*
    public void setRunning(boolean running) {
        this.running = running;
    }
 */

    @Override
    public void run() {

    }

    /*public void checkCommandMetod(){
        while (gui.getCommand().equals(gui.getInputContext())){
            System.out.println("check");
        }
       }*/
  /*  public Person[] getNpc() {
        System.out.println("getnpc");
        return this.npc;
    }

    public Player getPlayer() {
        System.out.println("getplayer");
        return this.player;
    }

    public Room[] getMap(){
        System.out.println("getmap");
        return this.map;
    }
*/
    public Room getCurrentRoom(){
        System.out.println("get currentroom");
        return map[this.currentRoom];
    }

    public void UpdateRoom(){

    }

    public void UpdateNpc(){
        for (int i = 0; i < npc.length; i++){
            int currentRoom = npc[i].getLastRoom();
            map[currentRoom].remove(npc[i]);
        }

        for(int i = 0; i < npc.length; i++){
            int position = npc[i].getPosition();
            map[position].addNpc(npc[i]);
        }
    }
}
