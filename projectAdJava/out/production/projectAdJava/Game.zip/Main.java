public class Main {
    public static void main(String[] args) {
        //start a new Game
        new Game();
    }
}
