public class Container extends GameObject{

    //it got a name, a boolean if its movable or not because its inherit from GameObject
    Inventory inventory;
    boolean locked;

    //name if this is movable or not at the beginning its true
    public Container(String name, boolean movable, boolean locked){
        //run superclass constructor
        super(name, movable);
        this.inventory = new Inventory(3);
        this.locked = locked;
    }

    //what do you have in your inventory
    public Inventory getInventory() {
        return this.inventory; }

    public boolean isLocked(){
        return this.locked;
    }

    @Override
    public String toString() { return "Container" + inventory + locked; }
}
//vad gör jag om den är låst mm är det låst skriver inte ut är den låst skriv inte ut med if satser
//metod för det hur hantera man?? ritar inte ut container mm