public class Update implements Runnable{
    private GUI gui;
    private String name;
    private int position;

    public Update() {
        this.gui = gui;
    }

    public void show (){
        System.out.println(this.name + " is in " +this.position);
    }
    public synchronized void move(int x){
        this.position =x;
    }

    @Override
    public void run() {
    /*    int rand = (int)(Math.random()*100)+1;
        if (rand<10 && this.position !=-1){
            this.position -= 1;
            System.out.println(this.name +" går åt vänster" + this.position);
        } else {
            this.position +=1;
            System.out.println(this.name +" går åt höger" + this.position);
        }
*/
    }
}
