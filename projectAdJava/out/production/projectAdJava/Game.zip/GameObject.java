public class GameObject {

    //this means that it is always instance variable
    private String name;
    boolean movable;

    //has a name and if it movable or not
    public GameObject(String name, boolean movable){
        this.name = name;
        this.movable = movable;
    }

    //get a movable
    public boolean isMovable(){
        return this.movable;
    }

    public String getName(){
        return this.name;
    }

    //do it to a string
    public String toString(){//this means instance variable in the class not the class
        return this.name;
    }

}
